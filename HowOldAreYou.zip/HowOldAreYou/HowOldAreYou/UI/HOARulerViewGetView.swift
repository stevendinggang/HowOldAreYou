//
//  UnitRulerViewGetView.swift
//  HowOldAreYou
//
//  Created by Steven on 2021/3/21.
//

import UIKit

class HOARulerViewGetView: NSObject {

    
    public func getRulerView(rulerViewCGRect:CGRect) -> HOARulerView {

           let numberTopRulerView:HOARulerView = HOARulerView(frame:rulerViewCGRect)

           return numberTopRulerView
    }
     
}
