//
//  ViewController.swift
//  HowOldAreYou
//
//  Created by Steven on 2021/3/20.
//

import UIKit
import SnapKit

let SCREEN_WIDTH:CGFloat = UIScreen.main.bounds.size.width
let SCREEN_HEIGHT:CGFloat = UIScreen.main.bounds.size.height
let rulerViewH = 120 //卡尺高度
let navH:Int = Int(UIApplication.shared.statusBarFrame.size.height) //系统高度
let barTopSpacing = navH

class ViewController: UIViewController {

    var tipsLabel = UILabel.init()
    var navBar:HOANavgationBar = HOANavgationBar.init()
    //年龄选择view
    var numberTopRulerView:HOARulerView = HOARulerView.init()
    var numberLabel = UILabel.init()
    @IBOutlet weak var ContinueBtn: UIButton!
    var year:String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        setUpUI()
    }

    func setUpUI(){
        self.view.backgroundColor = UIColor.colorWithHexString("FFFFFF")
        setTopBar()
        topRuler()
        setCenterNumber()
        setButtomBtn()
    }

}

//MARK: UI 
extension ViewController {

    fileprivate func setTopBar(){
        let bar = HOANavgationBar.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 60))
        self.view.addSubview(bar)
        bar.snp.makeConstraints({ (make) in
            make.leading.trailing.equalTo(self.view)
            make.top.equalTo(self.view.snp.top).offset(barTopSpacing)
            make.height.equalTo(60)
        })
        navBar = bar

        self.view.addSubview(tipsLabel)
        tipsLabel.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        tipsLabel.text = "How old are you?"
        tipsLabel.textColor = UIColor.colorWithHexString("525960")
        tipsLabel.snp.makeConstraints({ (make) in
            make.leading.equalTo(navBar.backBtn.snp.leading)
            make.top.equalTo(navBar.snp.bottom).offset(12)
        })

    }

    fileprivate func setCenterNumber(){

        let number = UIImageView.init()
        self.view.addSubview(number)
        number.image = UIImage.init(named: "image 1-3")
        number.snp.makeConstraints({ (make) in
            make.bottom.equalTo(self.numberTopRulerView.snp.top).offset(20)
            make.centerX.equalTo(self.view.snp.centerX)
            make.width.equalTo(110)
            make.height.equalTo(120)
        })

        let numberLabel = UILabel.init()
        numberLabel.textColor = UIColor.colorWithHexString("535A60")
        numberLabel.text = ""
        numberLabel.textAlignment = .center
        numberLabel.font = UIFont.getUIFont(size: 44, type: .bold)
        self.view.addSubview(numberLabel)
        numberLabel.snp.makeConstraints({ (make) in
            make.centerX.equalTo(number.snp.centerX)
            make.centerY.equalTo(number.snp.centerY).offset(-5)
            make.width.equalTo(number.snp.width)
        })
        self.numberLabel = numberLabel
    }

    fileprivate func setButtomBtn(){
        self.ContinueBtn.setTitle("Continue", for: .normal)
        self.ContinueBtn.titleLabel?.font = UIFont.getUIFont(size: 20, type: .semibold)
        self.updata(state: .disabled)
        self.ContinueBtn.isEnabled = false
        self.ContinueBtn.layer.cornerRadius = 45/2
        self.ContinueBtn.layer.cornerCurve = .continuous
        self.ContinueBtn.addTarget(self, action: #selector(clickContinueBtn), for: .touchUpInside)
    }


    fileprivate func topRuler(){
        let numberTopRulerView:HOARulerView = HOARulerView(frame: CGRect(x: 0, y: Int(SCREEN_HEIGHT)/2 - rulerViewH/2, width: Int(UIScreen.main.bounds.size.width), height: rulerViewH))
        numberTopRulerView.backgroundColor = UIColor.colorWithHexString("FFFFFF")
        numberTopRulerView.tag = 0
        numberTopRulerView.delegate = self
        var config = RulerrConfig()
        //刻度高度
        //短刻度尺高度
        config.shortScaleLength = 6.5
        //长刻度尺高度
        config.longScaleLength = 10
        //刻度宽度
        config.scaleWidth = 3
        //刻度起始位置(保证长刻度尺在短刻度尺上面)
        config.shortScaleStart = CGFloat(rulerViewH/2)
        config.longScaleStart = config.shortScaleStart
        //刻度颜色
        config.scaleColor = HEXCOLOR(c:0xdae0ed)
        //刻度之间的距离
        config.distanceBetweenScale = 8
        //刻度距离数字的距离
        config.distanceFromScaleToNumber = 10
        //指示视图属性设置
        config.pointSize = CGSize(width: 5, height: 50)
        //center 颜色
        config.pointColor = UIColor.colorWithHexString("7BCCD6")
        config.pointStart = CGFloat(rulerViewH/2) - 15
        //刻盘文字属性
        config.numberFont = UIFont.getUIFont(size: 15, type: .semibold)
        //刻盘文字颜色
        config.numberColor = HEXCOLOR(c: 0x4A4A4A)
        //刻盘数字所在位置方向
        config.numberDirection = .numberBottom
        //刻度尺反向
        config.reverse = false
        //是否隐藏线
        config.isHiddenBottomLine = false
        //取值范围
        config.max = 108
        config.min = 8
        //默认值
        config.defaultNumber = 34
        //使用小数类型
        config.isDecimal = false
        //选中
        config.selectionEnable = true
        //使用渐变背景
        config.useGradient = true

        numberTopRulerView.rulerConfig = config
        self.view.addSubview(numberTopRulerView)
        self.numberTopRulerView = numberTopRulerView
    }

}


//MARK: RulerViewDelegate
extension ViewController : RulerViewDelegate {

    func rulerSelectValue(value: Double, tag: NSInteger) {
        print("select vale is \(value) is index \(tag)")
        let IntValue = Int(value)
        let newValue = String(IntValue)
        self.year = newValue
        numberLabel.text = newValue
        if self.ContinueBtn.isEnabled == false {
            self.updata(state: .normal)
        }
    }

}


//MARK: ViewController BottomButton
extension ViewController {

    @objc public func clickContinueBtn() {

        let alertController = UIAlertController(title: "How Old Are You ?", message: "You Choose \(self.year)", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "YES", style: .default, handler: { action in
        })
        let cancelAction = UIAlertAction(title: "NO", style: .cancel, handler: nil)
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)

    }

    //MARK -
    func updata(state: UIControl.State) {
        if state == .normal {
            self.ContinueBtn.isEnabled = true
            self.ContinueBtn.backgroundColor = UIColor.colorWithHexString("7BCCD6")
            self.ContinueBtn.setTitleColor(UIColor.colorWithHexString("FFFFFF"), for: .normal)
        } else if state == .disabled {
            self.ContinueBtn.isEnabled = false
            self.ContinueBtn.backgroundColor = UIColor.gray
            self.ContinueBtn.setTitleColor(UIColor.white, for: .disabled)
        }
    }
}
