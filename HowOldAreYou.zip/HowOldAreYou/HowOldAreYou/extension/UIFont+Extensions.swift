//
//  UIFont+Extensions.swift
//  HowOldAreYou
//
//  Created by Steven on 2021/3/20.
//


import UIKit


public enum FontType {
    case thin
    case regular
    case medium
    case semibold
    case bold

    @available(iOS 8.2, *)
    func systemWeight() -> UIFont.Weight {
        switch self {
        case .thin:
            return UIFont.Weight.thin
        case .regular:
            return UIFont.Weight.regular
        case .medium:
            return UIFont.Weight.medium
        case .semibold:
            return UIFont.Weight.semibold
        case .bold:
            return UIFont.Weight.bold
        }
    }
}

// UIFont + Extension
extension UIFont {

    // MARK:系统字体，默认字号16，Weight为regular
    public class func getUIFont(size: CGFloat, type: FontType) -> UIFont! {
        if #available(iOS 8.2, *) {
            return UIFont.systemFont(ofSize: size, weight: type.systemWeight())
        } else {
            switch type {
            case .thin,.regular:
                return UIFont.systemFont(ofSize: size)
            case .bold,.semibold:
                return UIFont.boldSystemFont(ofSize: size)
            default:
                return UIFont.systemFont(ofSize: size)
            }
        }
    }
}



