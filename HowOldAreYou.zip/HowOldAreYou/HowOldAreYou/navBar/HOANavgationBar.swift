//
//  HOANavgationBar.swift
//  HowOldAreYou
//
//  Created by Steven on 2021/3/21.
//

import UIKit

class HOANavgationBar: UIView {

    var backBtn = UIButton.init()
    var progressLabel = UILabel.init()
    var progressView: UIProgressView = {
        var progressView = UIProgressView()
        progressView = UIProgressView(progressViewStyle: .default)
        progressView.frame = CGRect(x: 0, y: Int(navH) + barTopSpacing, width: 200, height: 20)
        progressView.progressTintColor = UIColor.colorWithHexString("7BCCD6")
        return progressView
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.yellow
        self.setTop()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    fileprivate func setTop(){

        self.addSubview(backBtn)
        backBtn.setImage(UIImage.init(named: "imageLeft"), for: .normal)
        backBtn.snp.makeConstraints({ (make) in
            make.leading.equalTo(self.snp.leading).offset(20)
            make.width.height.equalTo(20)
            make.centerY.equalTo(self.snp.centerY)
        })

        self.addSubview(progressLabel)
        progressLabel.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        progressLabel.text = "1/8"
        progressLabel.textAlignment = .right
        progressLabel.textColor = UIColor.colorWithHexString("525960")
        progressLabel.snp.makeConstraints({ (make) in
            make.trailing.equalTo(self.snp.trailing).offset(-20)
            make.top.equalTo(self.backBtn.snp.top)
        })

        setProgressView()

    }

    fileprivate func setProgressView(){
        progressView.progress = 1/8
        progressView.layer.position = CGPoint(x: Int(self.frame.width)/2, y: Int(navH) + barTopSpacing)
        self.addSubview(progressView)
        progressView.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self.backBtn.snp.centerY)
            make.leading.equalTo(self.backBtn.snp.trailing).offset(30)
            make.trailing.equalTo(self.progressLabel.snp.leading).offset(-30)
        })
    }
}
